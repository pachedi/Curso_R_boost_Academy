
# Instalar paquetes
install.packages("openxlsx")
install.packages("tidyverse")

# Activar paquetes
library(openxlsx)
library(tidyverse)

# Cargar un csv desde mi disco local (tienen que poner la ruta
# de sus computadoras)
potenciar <- read.csv("potenciar-trabajo-titulares-activos.csv")


# Misma base pero cargada desde un link
base <- read.csv('https://raw.githubusercontent.com/pachedi/INTRO_R_CS/main/potenciar-trabajo-titulares-activos.csv', encoding = "UTF-8")

rm(potenciar)

# Nombre de columnas de un objeto
colnames(base)

# Valores unicos de una columna
unique(base$provincia)


provincias <- unique(base$provincia)
provincias

provincias <- as.data.frame(provincias)

# Valores resumen de una tabla
summary(base)

# Encabezado (primeros seis registros)
head(base)

# Ultimos 6 registros
tail(base)

# Filtrar por un valor
Mendoza <- base %>% 
  filter(provincia == "Mendoza")

unique(Mendoza$provincia)

# Seleccionar columnas y renombar otra columna
mendoza_recortado <- Mendoza %>% 
  select(provincia, departamento, municipio, titulares) %>% 
  rename(cantidad_de_titulares = titulares)

colnames(mendoza_recortado)

# Crear una nueva columna
mendoza_por_dos <- mendoza_recortado %>% 
  mutate(titulares_por_dos = cantidad_de_titulares * 2)

# Paquete para fechas
install.packages("lubridate")
library(lubridate)

class(base$periodo)

# Transformo a formato fecha
base <- base %>% 
  mutate(periodo = ymd(periodo))

class(base$periodo)

# Creo nueva columna mes / año
base <- base %>% 
  mutate(mes =months(periodo))

base <- base %>% 
  mutate(anio = year(periodo))

base$periodo[1] + days(1)
base$periodo[1] + years(1)

# Ordeno la base por titulares
base <- base %>% 
  arrange(titulares)

base <- base %>% 
  arrange(-titulares)

max(base$titulares)

# Variable resumen: promedio de titulares
promedio <- base %>% 
  summarise(promedio_titulares = mean(titulares))

# Agrupamiento por provincia y periodo
agrupado <- base %>% 
  group_by(provincia, periodo) %>% 
  summarise(total_titulares = sum(titulares))

# obtengo mi directorio de trabajo
getwd()

# guardo mi objeto en formato xlsx
write.xlsx(agrupado, "trabajo_clase_2.xlsx")
